VSWEP.Base = "missile_launcher"
VSWEP.Name = "#glide.weapons.barrage_missiles"
VSWEP.Icon = "glide/icons/rocket.png"

if SERVER then
    VSWEP.FireDelay = 0.3
end
