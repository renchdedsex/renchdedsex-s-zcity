hg.RolePlus = hg.RolePlus or {}
local PLUGIN = hg.RolePlus
