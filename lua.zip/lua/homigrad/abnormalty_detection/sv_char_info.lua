--\\Перевод плагиновых штук в ваши штуки
hg.Abnormalties = hg.Abnormalties or {}
local PLUGIN = hg.Abnormalties
--//

local ci = PLUGIN.CharInfo

-- ci["a"] = "harm"
-- ci["b"] = "shield"
-- ci["c"] = "harm"
-- ci["d"] = "ritual"
-- ci["e"] = "mystery"
-- ci["f"] = "ritual"
-- ci["g"] = "shield"
-- ci["h"] = "shield"
-- ci["i"] = "mystery"
-- ci["j"] = "harm"
-- ci["k"] = "blood"
-- ci["l"] = "shield"
-- ci["m"] = "harm"
-- ci["n"] = "blood"
-- ci["o"] = "shield"
-- ci["p"] = "harm"
-- ci["q"] = "ritual"
-- ci["r"] = "blood"
-- ci["s"] = "harm"
-- ci["t"] = "shield"
-- ci["u"] = "harm"
-- ci["v"] = "blood"
-- ci["w"] = "harm"
-- ci["x"] = "shield"
-- ci["y"] = "harm"
-- ci["z"] = "ritual"