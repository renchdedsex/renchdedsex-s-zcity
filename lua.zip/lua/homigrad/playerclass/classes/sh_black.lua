local CLASS = player.RegClass("black")

function CLASS.Off(self)
    if CLIENT then return end
end

local masks = {
    "Hood mask",
    "biker black eyeglasses",
    "bandana"
}
local clothing_pool = {
    [1] = {
        "models/humans/male/sheet_28"
    },
    [2] = {
        "models/humans/female/sheet_03"
    }
}

local function ApplyClothingVMT(ply, tMdl, vmt)
    if not istable(tMdl) then return end
    local mats = ply:GetMaterials()
    for k, v in pairs(tMdl.submatSlots) do
        if k ~= "main" and k ~= "pants" and k ~= "boots" then continue end
        local slot = nil
        for i = 1, #mats do
            if mats[i] == v then slot = i - 1 break end
        end
        if slot ~= nil then
            ply:SetSubMaterial(slot, vmt)
        end
    end
end

function CLASS.On(self)
    if CLIENT then return end
    timer.Simple(.1,function()
        local Appearance = hg.Appearance.GetRandomAppearance()

        Appearance.AAttachments = {
            masks[math.random(#masks)],
        }
        self:SetNetVar("Accessories", Appearance.AAttachments or "none")
        hg.Appearance.ForceApplyAppearance(self, Appearance)
        local tMdl = hg.Appearance.PlayerModels[1][Appearance.AModel] or hg.Appearance.PlayerModels[2][Appearance.AModel] or Appearance.AModel
        local sex = (istable(tMdl) and tMdl.sex) and 2 or 1
        local pool = clothing_pool[sex] or clothing_pool[1]
        local vmt = pool[math.random(#pool)]
        ApplyClothingVMT(self, tMdl, vmt)
        
        self.CurAppearance = Appearance
    end)
end

function CLASS.Guilt(self, victim)
    if CLIENT then return end

    if victim:GetPlayerClass() == self:GetPlayerClass() then
        return 1
    end
    
    if victim == zb.hostage then
        return 1
    end
end
