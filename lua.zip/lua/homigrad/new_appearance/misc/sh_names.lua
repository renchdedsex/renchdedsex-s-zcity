hg.Appearance = hg.Appearance or {}

local RandomNames = {
    [1] = { -- MaleNames
        "Mike",
        "Dave",
        "Michel",
        "John",
        "Fred",
        "Michiel",
        "Steven",
        "Sergio",
        "Joel",
        "Samuel",
        "Larry",
        "Sean",
        "Thomas",
        "Jose",
        "Bobby",
        "Richard",
        "David"
    },
    [2] = { -- FemaleNames
        "Denise",
        "Joyce",
        "Jane",
        "Sara",
        "Emily",
        "Charlotte",
        "Cathy",
        "Ruth",
        "Julia",
        "Tanya",
        "Wanda",
        "Elizabeth",
        "Nicole",
        "Stacey",
        "Mary",
        "Anna",
        "Diana"
    }
}

hg.Appearance.RandomNames = RandomNames