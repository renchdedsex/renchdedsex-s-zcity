ENT.Type = "anim"
ENT.Base = "base_gmodentity"
ENT.PrintName = "ent_hg_smokenade"
ENT.Spawnable = false
ENT.Model = "models/props_junk/jlare.mdl"
ENT.timeToBoom = 1