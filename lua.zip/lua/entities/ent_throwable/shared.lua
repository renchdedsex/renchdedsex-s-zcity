ENT.Type = "anim"
ENT.Base = "base_gmodentity"
ENT.PrintName = "Throwable base"
ENT.Spawnable = false
ENT.WorldModel = "models/jaanus/shuriken_small.mdl"
ENT.MaxSpeed = 1500

ENT.AttackHit = "Canister.ImpactHard"
ENT.AttackHitFlesh = "snd_jack_hmcd_axehit.wav"
ENT.Throwable = true