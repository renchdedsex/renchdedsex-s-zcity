ENT.Type = "anim"
ENT.Base = "base_anim"
ENT.PrintName = "Support Crate"
ENT.Category = "Govno deki"
ENT.Spawnable = false