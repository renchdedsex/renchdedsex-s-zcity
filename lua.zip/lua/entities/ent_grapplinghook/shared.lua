ENT.Type = "anim"
ENT.PrintName = "Grappling Hook"
ENT.Author = "metal factory"
ENT.Category = "ZCity Other"
ENT.Spawnable = false