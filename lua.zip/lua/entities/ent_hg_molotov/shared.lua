ENT.Type = "anim"
ENT.Author = "Mannytko"
ENT.Category = "ZCity Other"
ENT.PrintName = "Molotov Cocktail"
ENT.Spawnable = true
ENT.AdminOnly = true
ENT.IconOverride = "vgui/wep_jack_hmcd_molotov.png"