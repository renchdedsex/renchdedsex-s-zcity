ENT.Base = "ent_hg_grenade"
ENT.Spawnable = false
ENT.Model = "models/weapons/w_m84.mdl"
ENT.timeToBoom = 2.5
ENT.SoundMain = "weapons/m84/m84_detonate.wav"
ENT.SoundFar = "weapons/m84/m84_detonate_far_dist.wav"
ENT.SoundBass = {
    "snd_jack_fireworksplodeclose.wav",
    "snd_jack_fireworksplodefar.wav"
}