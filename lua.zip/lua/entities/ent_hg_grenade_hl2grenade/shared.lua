ENT.Base = "ent_hg_grenade"
ENT.Spawnable = false
ENT.Model = "models/Items/grenadeAmmo.mdl"
ENT.timeToBoom = 3
ENT.Fragmentation = 320 * 2
ENT.BlastDis = 5 --meters
ENT.Penetration = 7.5