ENT.Type = "anim"
ENT.Author = "Mannytko"
ENT.Category = "ZCity Other"
ENT.PrintName = "Bugbait"
ENT.Spawnable = true
ENT.AdminOnly = false
ENT.IconOverride = "entities/weapon_bugbait.png"