ENT.Type = "anim"
ENT.Base = "base_gmodentity"
ENT.Spawnable = false
ENT.WorldModel = "models/props_junk/wood_pallet001a_chunka1.mdl"
ENT.ModelScale = 0.4