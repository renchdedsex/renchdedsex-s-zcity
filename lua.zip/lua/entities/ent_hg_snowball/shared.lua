ENT.Type = "anim"
ENT.Author = "Mannytko"
ENT.Category = "ZCity Other"
ENT.PrintName = "Snowball"
ENT.Spawnable = true
ENT.AdminOnly = false
ENT.IconOverride = "vgui/wep_jack_hmcd_snowball"