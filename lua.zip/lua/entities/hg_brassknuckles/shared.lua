ENT.Type = "anim"
ENT.Base = "base_gmodentity"
ENT.PrintName = "Brass Knuckles"
ENT.Category = "ZCity Other"
ENT.Spawnable = true
ENT.IconOverride = "vgui/inventory/weapon_brassknuckles"
ENT.IsZPickup = true