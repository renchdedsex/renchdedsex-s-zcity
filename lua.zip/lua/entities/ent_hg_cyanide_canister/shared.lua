ENT.Type = "anim"
ENT.Base = "base_gmodentity"
ENT.PrintName = "Cyanide canister"
ENT.Spawnable = false
ENT.totalparticles = 30
ENT.Model = "models/jordfood/jtun.mdl"