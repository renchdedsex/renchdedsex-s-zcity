﻿if SERVER then AddCSLuaFile() end
ENT.Base = "ent_hg_grenade"
ENT.Spawnable = false
ENT.Model = "models/weapons/tfa_ins2/w_m67.mdl"
ENT.spoon = "models/weapons/arc9/darsu_eft/skobas/m67_skoba.mdl"
ENT.timeToBoom = 5
ENT.Fragmentation = 350 * 2 -- 450 уже страшно
ENT.BlastDis = 5 --meters
ENT.Penetration = 7