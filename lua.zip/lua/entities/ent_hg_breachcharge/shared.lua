ENT.Type = "anim"
ENT.Base = "base_anim"
ENT.PrintName = "ent_hg_breachcharge"
ENT.Spawnable = false
ENT.NextBeep = 0