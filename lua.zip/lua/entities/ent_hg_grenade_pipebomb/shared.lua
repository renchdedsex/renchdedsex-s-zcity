ENT.Base = "ent_hg_grenade"
ENT.Spawnable = false
ENT.Model = "models/w_models/weapons/w_jj_pipebomb.mdl"
ENT.timeToBoom = 4
ENT.Fragmentation = 270 * 2
ENT.BlastDis = 4 --meters
ENT.Penetration = 5.5
ENT.NotSpoon = true